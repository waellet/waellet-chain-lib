import { BaseProtocol } from "../BaseProtocol";

export class Aeternity extends BaseProtocol<Aeternity> {
    
}