export interface Tx<T> {
    sign(): Promise<string>;
    prepare(): Promise<string>;
    broadcast(): Promise<string>;
}