export interface Account<T> {

}