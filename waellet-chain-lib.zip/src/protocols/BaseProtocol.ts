import { Account } from '../interfaces/Account'
import { Tx } from '../interfaces/Tx'

export abstract class BaseProtocol<T> {
    account: Account<T>;
    tx: Tx<T>;
}